// Umair Hassan Class ID 3137 SE(C)
#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int a,b,c;
	double y1,y2;
	cout<<"Enter a ";
	cin>>a;
	cout<<"Enter b ";
	cin>>b;
	cout<<"Enter c ";
	cin>>c;
     int det =b*b-4*a*c;
	if( a!=0 ) {
	
	y1=(-b+sqrt(det))/(2*a);
	y2=(-b-sqrt(det))/(2*a);
	if(det==0){
	cout<<"Roots are equal and real"<<endl;
	cout<<"R1 = "<<y1<<endl;
	cout<<"R1 = "<<y2<<endl;
	}
 else if (det>0){
 	cout<<"Roots are different and real"<<endl;
	cout<<"R1 = "<<y1<<endl;
	cout<<"R1 = "<<y2<<endl;
 
 	} 
  else {
  	y1=(-b+sqrt(det))/(2*a);
	y2=(-b-sqrt(det))/(2*a);
	cout<<"Roots are complex and different"<<endl;
	cout<<"R1 = "<<y1<<"i"<<endl;
	cout<<"R1 = "<<y2<<"i"<<endl;
 
	
  	}
  	
 
	}
	else{
	
	
	cout<<"a cannot be zero "<<endl;
	}

 }
