// Umair Hassan Class ID 3137 SE(C)
#include<iostream>
#include<cmath>
using namespace std;
int main(){
 	double a,b,c,d,fx,x;
 	
 	cout<<"Enter value of x ";
 	cin>>x;
 	a=(x*x*x+5*x*x-4*x+3)/(2*x*x*x*x+7*x*x*x-3*x*x+6);
 	b=(x*x-3*x+2)/(4*x-5*x*x+8);
 	fx=a-cbrt(b);
 	
 	cout<<"x = "<<fx<<endl;
}
