// Umair Hassan Class ID 3137 SE(C)
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main(){
	int steps,opts,opt;
	
	int pwr=rand()%20;
	 int pnts=100;
	srand(time(0));
	steps=rand()%20+1;
	while(steps>0){
	cout<<"Now You want to flee or fight"<<endl;
	cout<<" 1 Fight"<<endl;
	cout<<" 2 flee "<<endl;
	cin>>opts;
	
	if(opts==1){
	pnts=pnts-pwr;
	}
	
	steps--;
	}
	if(pnts>0){
	cout<<"I fight, still survive"<<endl;
	}
	else
	cout<<"You loose"<<endl;
	
	
	
	
	}
