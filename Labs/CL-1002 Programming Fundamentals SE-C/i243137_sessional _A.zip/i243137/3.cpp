// Umair Hassan Class ID 3137 SE(C)
#include<iostream>
#include<cmath>
using namespace std;
int main(){
	int prdct,opt;
	float total=0,price,amnt,chng;
	cout<<"Vending Machine Menu"<<endl;
	cout<<"1. Snack A - $1.50 "<<endl;
	cout<<"2. Snack B - $2.00 "<<endl;
	cout<<"3. Drink A - $1.00 "<<endl;
	cout<<"3. Drink B - $1.00 "<<endl;
	while(prdct!=-1){
	cin>>prdct;
	
	switch(prdct){
	case 1:
	price=1.50;
	break;
	case 2:
	price=2.00;
	break;
	case 3:
	price=1.00;
	break;
	case 4:
	price=1.25;
	break;
	
	}
	total=total+price;
	
	
	}
	cout<<"Total Price "<<total<<endl;
	cout<<"Select Payment method"<<endl;
	cout<<"1. Cash "<<endl;
	cout<<"1. Pay with card "<<endl;
	cin>>opt;
	if(opt==1){
	cout<<"Enter amount in dollors : $ "<<endl;
	cin>>amnt;
	if(amnt<total){
	cout<<"Insufficent balnce "<<endl;
	}
	chng=total-amnt;
	cout<<" Change "<<chng<<endl;
	cout<<"Message : Change $ "<<chng<<endl;
	}
	else{
	cout<<"Message : Card Payment Successfull "<<endl;
	}

	}
	
