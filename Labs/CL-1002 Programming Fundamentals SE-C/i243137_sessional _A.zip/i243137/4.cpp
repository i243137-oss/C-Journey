// Umair Hassan Class ID 3137 SE(C)
#include<iostream>
#include<cmath>
using namespace std;
int main(){
int x;
string relat;
bool flag;
char  y;
     do{
	cout<<"Enter Generation ";
	cin>>x;
	cout<<"Enter Character ";
	cin>>y;
	flag=(x>=-3 && x<=3 ) && (y=='f' || y=='m');
	}while(!flag);
	switch(x){
	case -3:
	if(y=='f'){
	relat="great grandmother";
	}
	else{
	relat="great grandfather";
	
	}
	break;
	case -2:
	if(y=='f'){
	relat=" grandmother";
	}
	else{
	relat="grand father";
	}
	break;
	case -1:
	if(y=='f'){
	relat=" mother";
	}
	else{
	relat= "father";
	}
	break;
	case 0:
	if(y=='f'){
	relat=" me";
	}
	else{
	relat=" me";
	}
	break;
	case 1:
	if(y=='f'){
	relat=" me";
	}
	else{
	relat=" me";
	}
	break;
	case 2:
	if(y=='f'){
	relat=" daughter";
	}
	else{
	relat=" son";
	}
	break;
	case 3:
	if(y=='f'){
	relat=" granddaughter";
	}
	else{
	relat=" grandson";
	}
	break;
	
	}
	cout<<relat<<endl;
	}
	
	
	

